package com.slensky.focussis.util;

/**
 * Created by slensky on 5/14/17.
 */

public class EventUtil {
}
