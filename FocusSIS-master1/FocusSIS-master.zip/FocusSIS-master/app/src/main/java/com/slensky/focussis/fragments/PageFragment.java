package com.slensky.focussis.fragments;

/**
 * Created by slensky on 5/1/17.
 */

public interface PageFragment {
    public String getTitle();
}
