package com.slensky.focussis.util;

/**
 * Created by slensky on 4/28/18.
 */

public interface Syncable {
    public void sync();
}
